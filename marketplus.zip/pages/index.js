import Image from 'next/image'
import { Inter } from 'next/font/google'
import ProductsComponent from '@/components/pages/products'
import MainLayout from '@/components/layout/main.layout'

const inter = Inter({ subsets: ['latin'] })

export default function Home() {
  return (
    <main
      className={`flex min-h-screen flex-col`}
    >
      <MainLayout/>
     {/* <ProductsComponent/> */}
    </main>
  )
}
